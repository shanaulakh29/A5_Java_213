package org.example.DTO;

public class ApiOfferingSectionDTO {
    public String type;
    public int enrollmentCap;
    public int enrollmentTotal;

    public ApiOfferingSectionDTO(String type, int enrollmentCap, int enrollmentTotal) {
        this.type = type;
        this.enrollmentCap = enrollmentCap;
        this.enrollmentTotal = enrollmentTotal;
    }

    public void addIntoEnrollmentTotal(int enrollmentTotal) {
        this.enrollmentTotal += enrollmentTotal;
    }
}
