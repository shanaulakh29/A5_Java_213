package org.example.DTO;

public final class ApiWatcherCreateDTO {
    public long deptId;
    public long courseId;
}
